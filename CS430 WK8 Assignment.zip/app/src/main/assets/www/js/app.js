﻿// Global vars

var user = null;

var database = null;

var attachedFiles = [];



document.addEventListener('deviceready', function () {

console.log('Ready');

database = firebase.database();

init();

}, false);



// fallback for browser testing

if (!window.cordova) {

window.addEventListener('load', function () {

database = firebase.database();

init();

});

}



function init() {

firebase.auth().onAuthStateChanged(function (u) {

if (u) {

user = u;

loadDashboard();

} else {

loginScreen();

}

});

}



function loginScreen() {

var html = '<div class="screen">';

html += '<div class="logo">$</div>';

html += '<h1>Microfinance Loan Tracker</h1>';

html += '<div class="card">';

html += '<h2>Login</h2>';

html += '<input type="email" id="email" placeholder="Email" class="input" />';

html += '<input type="password" id="password" placeholder="Password" class="input" />';

html += '<button onclick="saveBranch()" class="btn btn-primary btn-full">Add Branch</button>';

html += '</div></div>';



document.getElementById('app').innerHTML = html;

}



function useMyLocation() {

var status = document.getElementById('branchLocationStatus');

status.innerHTML = '<div class="spinner">Getting location...</div>';



navigator.geolocation.getCurrentPosition(function (pos) {

document.getElementById('branchLat').value = pos.coords.latitude;

document.getElementById('branchLon').value = pos.coords.longitude;

status.innerHTML = '<div class="success">✓ Location captured!</div>';

}, function (err) {

status.innerHTML = '<div class="error">Error: ' + err.message + '</div>';

}, { enableHighAccuracy: true, timeout: 10000 });

}



function saveBranch() {

var name = document.getElementById('branchName').value;

var addr = document.getElementById('branchAddress').value;

var phone = document.getElementById('branchPhone').value;

var lat = parseFloat(document.getElementById('branchLat').value);

var lon = parseFloat(document.getElementById('branchLon').value);



if (!name || !addr || !lat || !lon) {

alert('Please fill all required fields');

return;

}



if (isNaN(lat) || isNaN(lon)) {

alert('Invalid coordinates');

return;

}



database.ref('branches').push({

name: name,

address: addr,

phone: phone,

latitude: lat,

longitude: lon,

createdBy: user.uid,

createdAt: firebase.database.ServerValue.TIMESTAMP

}).then(function () {

branchScreen();

}).catch(function (err) {

alert('Failed to add branch: ' + err.message);

});

}



function removeBranch(id) {

if (!confirm('Are you sure you want to delete this branch?')) return;



database.ref('branches/' + id).remove().catch(function (err) {

alert('Failed to delete branch: ' + err.message);

});

}



function openMaps(lat, lon) {

var url = 'https://www.google.com/maps/search/?api=1&query=' + lat + ',' + lon;

if (window.cordova) {

window.open(url, '_system');

} else {

window.open(url, '_blank');

}

}



function registerScreen() {

var html = '<div class="screen">';

html += '<div class="logo">$</div>';

html += '<h1>Create Account</h1>';

html += '<div class="card">';

html += '<input type="text" id="name" placeholder="Full Name" class="input" />';

html += '<input type="email" id="email" placeholder="Email" class="input" />';

html += '<input type="password" id="password" placeholder="Password" class="input" />';

html += '<input type="password" id="confirmPassword" placeholder="Confirm Password" class="input" />';

html += '<button onclick="doRegister()" class="btn btn-primary">Register</button>';

html += '<button onclick="loginScreen()" class="btn btn-secondary">Back to Login</button>';

html += '</div></div>';

document.getElementById('app').innerHTML = html;

}



function doLogin() {

var email = document.getElementById('email').value;

var pass = document.getElementById('password').value;



if (!email || !pass) {

alert('Please enter email and password');

return;

}



firebase.auth().signInWithEmailAndPassword(email, pass).catch(function (err) {

alert('Login failed: ' + err.message);

});

}



function doRegister() {

var name = document.getElementById('name').value;

var email = document.getElementById('email').value;

var pass = document.getElementById('password').value;

var pass2 = document.getElementById('confirmPassword').value;



if (!name || !email || !pass) {

alert('Please fill all fields');

return;

}



if (pass !== pass2) {

alert('Passwords do not match');

return;

}



if (pass.length < 6) {

alert('Password must be at least 6 characters');

return;

}



firebase.auth().createUserWithEmailAndPassword(email, pass).then(function (cred) {

database.ref('users/' + cred.user.uid).set({

name: name,

email: email,

createdAt: firebase.database.ServerValue.TIMESTAMP

});

}).catch(function (err) {

alert('Registration failed: ' + err.message);

});

}



function loadDashboard() {

var html = '<div class="screen">';

html += '<div class="header">';

html += '<h1>Loan Tracker</h1>';

html += '<button onclick="doLogout()" class="btn btn-small">Logout</button>';

html += '</div>';



html += '<div class="stats">';

html += '<div class="stat-card"><div class="stat-value" id="totalLoans">0</div><div class="stat-label">Total Loans</div></div>';

html += '<div class="stat-card"><div class="stat-value" id="activeLoans">0</div><div class="stat-label">Active</div></div>';

html += '<div class="stat-card"><div class="stat-value" id="totalAmount">$0</div><div class="stat-label">Total Amount</div></div>';

html += '</div>';



html += '<button onclick="addLoanScreen()" class="btn btn-primary btn-full">+ Add New Loan</button>';

html += '<button onclick="calculatorScreen()" class="btn btn-secondary btn-full">🧮 Loan Calculator</button>';

html += '<button onclick="branchScreen()" class="btn btn-secondary btn-full">📍 Branch Locator</button>';

html += '<div id="loansList"></div>';

html += '</div>';



document.getElementById('app').innerHTML = html;

loadAllLoans();

}



function loadAllLoans() {

var ref = database.ref('loans/' + user.uid);



ref.on('value', function (snap) {

var loans = [];

snap.forEach(function (child) {

var loan = child.val();

loan.id = child.key;

loans.push(loan);

});



showLoans(loans);

calcStats(loans);

});

}



function showLoans(loans) {

var list = document.getElementById('loansList');



if (loans.length === 0) {

list.innerHTML = '<div class="empty">No loans yet. Click "Add New Loan" to get started.</div>';

return;

}



var html = '<h2>Your Loans</h2>';



for (var i = 0; i < loans.length; i++) {

var l = loans[i];

html += '<div class="loan-card">';

html += '<div class="loan-header">';

html += '<h3>' + l.borrowerName + '</h3>';

html += '<span class="status status-' + l.status + '">' + l.status + '</span>';

html += '</div>';

html += '<div class="loan-details">';

html += '<div class="detail"><span class="label">Amount:</span><span class="value">$' + l.amount + '</span></div>';

html += '<div class="detail"><span class="label">Interest:</span><span class="value">' + l.interestRate + '%</span></div>';

html += '<div class="detail"><span class="label">Duration:</span><span class="value">' + l.duration + ' months</span></div>';

html += '<div class="detail"><span class="label">Date:</span><span class="value">' + new Date(l.date).toLocaleDateString() + '</span></div>';

html += '</div>';

html += '<div class="loan-actions">';

html += '<button onclick="viewLoanDetails(\'' + l.id + '\')" class="btn btn-small">View Details</button>';

html += '<button onclick="removeLoan(\'' + l.id + '\')" class="btn btn-small btn-danger">Delete</button>';

html += '</div>';

html += '</div>';

}



list.innerHTML = html;

}



function calcStats(loans) {

var total = loans.length;

var active = 0;

var sum = 0;



for (var i = 0; i < loans.length; i++) {

if (loans[i].status === 'active') active++;

sum += parseFloat(loans[i].amount || 0);

}



document.getElementById('totalLoans').textContent = total;

document.getElementById('activeLoans').textContent = active;

document.getElementById('totalAmount').textContent = '$' + sum.toFixed(2);

}



function addLoanScreen() {

var html = '<div class="screen">';

html += '<div class="header">';

html += '<button onclick="loadDashboard()" class="btn btn-small">← Back</button>';

html += '<h1>Add New Loan</h1>';

html += '</div>';



html += '<div class="card">';

html += '<input type="text" id="borrowerName" placeholder="Borrower Name" class="input" />';

html += '<input type="number" id="amount" placeholder="Loan Amount" class="input" />';

html += '<input type="number" id="interestRate" placeholder="Interest Rate (%)" class="input" />';

html += '<input type="number" id="duration" placeholder="Duration (months)" class="input" />';

html += '<input type="date" id="date" class="input" />';

html += '<textarea id="notes" placeholder="Notes (optional)" class="input" rows="3"></textarea>';



html += '<label class="label">Status:</label>';

html += '<select id="status" class="input">';

html += '<option value="active">Active</option>';

html += '<option value="pending">Pending</option>';

html += '<option value="paid">Paid</option>';

html += '<option value="overdue">Overdue</option>';

html += '</select>';



html += '<label class="label">Attachments (Optional):</label>';

html += '<div class="file-upload-section">';

html += '<button onclick="takePhoto()" class="btn btn-secondary">📷 Take Photo</button>';

html += '<button onclick="pickFile()" class="btn btn-secondary">📁 Choose File</button>';

html += '</div>';

html += '<div id="filePreview" class="file-preview"></div>';



html += '<button onclick="saveLoan()" class="btn btn-primary btn-full">Add Loan</button>';

html += '</div></div>';



document.getElementById('app').innerHTML = html;

document.getElementById('date').valueAsDate = new Date();

}



function saveLoan() {

var name = document.getElementById('borrowerName').value;

var amt = document.getElementById('amount').value;

var rate = document.getElementById('interestRate').value;

var dur = document.getElementById('duration').value;

var dt = document.getElementById('date').value;

var note = document.getElementById('notes').value;

var stat = document.getElementById('status').value;



if (!name || !amt || !rate || !dur || !dt) {

alert('Please fill all required fields');

return;

}



var loanData = {

borrowerName: name,

amount: parseFloat(amt),

interestRate: parseFloat(rate),

duration: parseInt(dur),

date: dt,

notes: note,

status: stat,

createdAt: firebase.database.ServerValue.TIMESTAMP

};



if (attachedFiles.length > 0) {

loanData.attachments = attachedFiles;

}



database.ref('loans/' + user.uid).push(loanData).then(function () {

attachedFiles = [];

loadDashboard();

}).catch(function (err) {

alert('Failed to add loan: ' + err.message);

});

}



function viewLoanDetails(id) {

database.ref('loans/' + user.uid + '/' + id).once('value').then(function (snap) {

var loan = snap.val();



if (!loan) {

alert('Loan not found');

return;

}



var html = '<div class="screen">';

html += '<div class="header">';

html += '<button onclick="loadDashboard()" class="btn btn-small">← Back</button>';

html += '<h1>Loan Details</h1>';

html += '</div>';



html += '<div class="card">';

html += '<h2>' + loan.borrowerName + '</h2>';

html += '<div class="loan-details">';

html += '<div class="detail"><span class="label">Amount:</span><span class="value">$' + loan.amount + '</span></div>';

html += '<div class="detail"><span class="label">Interest Rate:</span><span class="value">' + loan.interestRate + '%</span></div>';

html += '<div class="detail"><span class="label">Duration:</span><span class="value">' + loan.duration + ' months</span></div>';

html += '<div class="detail"><span class="label">Date:</span><span class="value">' + new Date(loan.date).toLocaleDateString() + '</span></div>';

html += '<div class="detail"><span class="label">Status:</span><span class="value status-' + loan.status + '">' + loan.status + '</span></div>';



var totalRepay = loan.amount * (1 + loan.interestRate / 100);

html += '<div class="detail"><span class="label">Total to Repay:</span><span class="value">$' + totalRepay.toFixed(2) + '</span></div>';



if (loan.notes) {

html += '<div class="detail"><span class="label">Notes:</span><span class="value">' + loan.notes + '</span></div>';

}



if (loan.attachments && loan.attachments.length > 0) {

html += '<div class="detail"><span class="label">Attachments:</span><div class="attachments-list">';

for (var i = 0; i < loan.attachments.length; i++) {

var att = loan.attachments[i];

if (att.type === 'image') {

html += '<div class="attachment-item"><img src="' + att.data + '" class="attachment-thumb" onclick="viewImage(\'' + att.data + '\')"/></div>';

}

}

html += '</div></div>';

}



html += '</div>';

html += '<button onclick="loadDashboard()" class="btn btn-primary btn-full">Back to Dashboard</button>';

html += '</div></div>';



document.getElementById('app').innerHTML = html;

});

}



function removeLoan(id) {

if (!confirm('Are you sure you want to delete this loan?')) return;



database.ref('loans/' + user.uid + '/' + id).remove().catch(function (err) {

alert('Failed to delete loan: ' + err.message);

});

}



function doLogout() {

if (confirm('Are you sure you want to logout?')) {

firebase.auth().signOut();

}

}



// file stuff

function takePhoto() {

if (!navigator.camera) {

alert('Camera not available');

return;

}



navigator.camera.getPicture(function (data) {

var img = 'data:image/jpeg;base64,' + data;

attachedFiles.push({ type: 'image', data: img, timestamp: Date.now() });

updatePreview();

}, function (err) {

alert('Failed to capture photo: ' + err);

}, {

quality: 50,

destinationType: Camera.DestinationType.DATA_URL,

sourceType: Camera.PictureSourceType.CAMERA,

encodingType: Camera.EncodingType.JPEG,

correctOrientation: true

});

}



function pickFile() {

if (!navigator.camera) {

// browser fallback

var input = document.createElement('input');

input.type = 'file';

input.accept = 'image/*';

input.onchange = function (e) {

var file = e.target.files[0];

if (file) {

var reader = new FileReader();

reader.onload = function (ev) {

attachedFiles.push({ type: 'image', data: ev.target.result, timestamp: Date.now() });

updatePreview();

};

reader.readAsDataURL(file);

}

};

input.click();

return;

}



navigator.camera.getPicture(function (data) {

var img = 'data:image/jpeg;base64,' + data;

attachedFiles.push({ type: 'image', data: img, timestamp: Date.now() });

updatePreview();

}, function (err) {

alert('Failed to select file: ' + err);

}, {

quality: 50,

destinationType: Camera.DestinationType.DATA_URL,

sourceType: Camera.PictureSourceType.PHOTOLIBRARY,

encodingType: Camera.EncodingType.JPEG

});

}



function updatePreview() {

var prev = document.getElementById('filePreview');

if (!prev) return;



if (attachedFiles.length === 0) {

prev.innerHTML = '';

return;

}



var html = '<div class="file-list"><p><strong>' + attachedFiles.length + ' file(s) attached</strong></p>';

for (var i = 0; i < attachedFiles.length; i++) {

html += '<div class="file-item">';

if (attachedFiles[i].type === 'image') {

html += '<img src="' + attachedFiles[i].data + '" class="file-thumb"/>';

}

html += '<button onclick="removeFile(' + i + ')" class="btn-remove">✕</button>';

html += '</div>';

}

html += '</div>';

prev.innerHTML = html;

}



function removeFile(idx) {

attachedFiles.splice(idx, 1);

updatePreview();

}



function viewImage(data) {

var app = document.getElementById('app');

var html = '<div class="fullscreen-image">';

html += '<button onclick="loadDashboard()" class="btn-close">✕ Close</button>';

html += '<img src="' + data + '" style="max-width: 100%; max-height: 90vh;"/>';

html += '</div>';

app.innerHTML = html;

}



// calculator

function calculatorScreen() {

var html = '<div class="screen">';

html += '<div class="header">';

html += '<button onclick="loadDashboard()" class="btn btn-small">← Back</button>';

html += '<h1>Loan Calculator</h1>';

html += '</div>';



html += '<div class="card">';

html += '<h2>Calculate Loan Details</h2>';

html += '<label class="label">Loan Amount ($):</label>';

html += '<input type="number" id="calcAmount" placeholder="Enter amount" class="input" value="1000" />';

html += '<label class="label">Interest Rate (% per year):</label>';

html += '<input type="number" id="calcRate" placeholder="Enter rate" class="input" value="12" step="0.1" />';

html += '<label class="label">Loan Duration (months):</label>';

html += '<input type="number" id="calcDuration" placeholder="Enter months" class="input" value="12" />';

html += '<label class="label">Interest Type:</label>';

html += '<select id="calcType" class="input">';

html += '<option value="simple">Simple Interest</option>';

html += '<option value="compound">Compound Interest (Monthly)</option>';

html += '<option value="reducing">Reducing Balance</option>';

html += '</select>';

html += '<button onclick="runCalc()" class="btn btn-primary btn-full">Calculate</button>';

html += '<div id="calcResults" class="calc-results"></div>';

html += '</div></div>';



document.getElementById('app').innerHTML = html;

}



function runCalc() {

var amt = parseFloat(document.getElementById('calcAmount').value);

var rate = parseFloat(document.getElementById('calcRate').value);

var months = parseInt(document.getElementById('calcDuration').value);

var type = document.getElementById('calcType').value;



if (!amt || !rate || !months) {

alert('Please fill all fields');

return;

}



var interest, total, monthly, html;



if (type === 'simple') {

interest = (amt * rate * (months / 12)) / 100;

total = amt + interest;

monthly = total / months;



html = '<div class="result-card">';

html += '<h3>Simple Interest Calculation</h3>';

html += '<div class="result-row"><span>Principal Amount:</span><strong>$' + amt.toFixed(2) + '</strong></div>';

html += '<div class="result-row"><span>Interest Rate:</span><strong>' + rate + '% per year</strong></div>';

html += '<div class="result-row"><span>Duration:</span><strong>' + months + ' months</strong></div>';

html += '<div class="result-row highlight"><span>Total Interest:</span><strong>$' + interest.toFixed(2) + '</strong></div>';

html += '<div class="result-row highlight"><span>Total Repayment:</span><strong>$' + total.toFixed(2) + '</strong></div>';

html += '<div class="result-row highlight"><span>Monthly Payment:</span><strong>$' + monthly.toFixed(2) + '</strong></div>';

html += '</div>';

} else if (type === 'compound') {

var r = rate / 100 / 12;

total = amt * Math.pow(1 + r, months);

interest = total - amt;

monthly = total / months;



html = '<div class="result-card">';

html += '<h3>Compound Interest Calculation</h3>';

html += '<div class="result-row"><span>Principal Amount:</span><strong>$' + amt.toFixed(2) + '</strong></div>';

html += '<div class="result-row"><span>Interest Rate:</span><strong>' + rate + '% per year (compounded monthly)</strong></div>';

html += '<div class="result-row"><span>Duration:</span><strong>' + months + ' months</strong></div>';

html += '<div class="result-row highlight"><span>Total Interest:</span><strong>$' + interest.toFixed(2) + '</strong></div>';

html += '<div class="result-row highlight"><span>Total Repayment:</span><strong>$' + total.toFixed(2) + '</strong></div>';

html += '<div class="result-row highlight"><span>Monthly Payment:</span><strong>$' + monthly.toFixed(2) + '</strong></div>';

html += '</div>';

} else {

var mr = rate / 100 / 12;

monthly = (amt * mr * Math.pow(1 + mr, months)) / (Math.pow(1 + mr, months) - 1);

total = monthly * months;

interest = total - amt;



html = '<div class="result-card">';

html += '<h3>Reducing Balance (EMI) Calculation</h3>';

html += '<div class="result-row"><span>Principal Amount:</span><strong>$' + amt.toFixed(2) + '</strong></div>';

html += '<div class="result-row"><span>Interest Rate:</span><strong>' + rate + '% per year</strong></div>';

html += '<div class="result-row"><span>Duration:</span><strong>' + months + ' months</strong></div>';

html += '<div class="result-row highlight"><span>Monthly EMI:</span><strong>$' + monthly.toFixed(2) + '</strong></div>';

html += '<div class="result-row highlight"><span>Total Interest:</span><strong>$' + interest.toFixed(2) + '</strong></div>';

html += '<div class="result-row highlight"><span>Total Repayment:</span><strong>$' + total.toFixed(2) + '</strong></div>';

html += '</div>';



// schedule

html += '<div class="amortization-schedule"><h4>Payment Schedule (First 6 months)</h4>';

var bal = amt;

for (var i = 1; i <= Math.min(6, months); i++) {

var intPay = bal * mr;

var prinPay = monthly - intPay;

bal -= prinPay;

html += '<div class="schedule-row">';

html += '<span>Month ' + i + ':</span>';

html += '<span>Principal: $' + prinPay.toFixed(2) + ', Interest: $' + intPay.toFixed(2) + ', Balance: $' + bal.toFixed(2) + '</span>';

html += '</div>';

}

html += '</div>';

}



document.getElementById('calcResults').innerHTML = html;

}



// branch locator

function branchScreen() {

var html = '<div class="screen">';

html += '<div class="header">';

html += '<button onclick="loadDashboard()" class="btn btn-small">← Back</button>';

html += '<h1>Branch Locator</h1>';

html += '</div>';



html += '<div class="card">';

html += '<button onclick="findNearby()" class="btn btn-primary btn-full">📍 Find Nearest Branch</button>';

html += '<button onclick="addBranchScreen()" class="btn btn-secondary btn-full">+ Add New Branch</button>';

html += '<div id="locationStatus" class="status-message"></div>';

html += '</div>';



html += '<div id="branchList"></div>';

html += '</div>';



document.getElementById('app').innerHTML = html;

loadBranches();

}



function findNearby() {

var status = document.getElementById('locationStatus');

status.innerHTML = '<div class="spinner">Getting your location...</div>';



if (!navigator.geolocation) {

status.innerHTML = '<div class="error">Geolocation not supported</div>';

return;

}



navigator.geolocation.getCurrentPosition(function (pos) {

var lat = pos.coords.latitude;

var lon = pos.coords.longitude;

status.innerHTML = '<div class="success">✓ Location found: ' + lat.toFixed(4) + ', ' + lon.toFixed(4) + '</div>';

findClosest(lat, lon);

}, function (err) {

status.innerHTML = '<div class="error">Error: ' + err.message + '</div>';

}, { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 });

}



function getDistance(lat1, lon1, lat2, lon2) {

var R = 6371;

var dLat = (lat2 - lat1) * Math.PI / 180;

var dLon = (lon2 - lon1) * Math.PI / 180;

var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2);

var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

return R * c;

}



function findClosest(lat, lon) {

database.ref('branches').once('value').then(function (snap) {

var branches = [];

snap.forEach(function (child) {

var b = child.val();

b.id = child.key;

b.distance = getDistance(lat, lon, b.latitude, b.longitude);

branches.push(b);

});

branches.sort(function (a, b) { return a.distance - b.distance; });

showBranches(branches, true);

});

}



function loadBranches() {

database.ref('branches').on('value', function (snap) {

var branches = [];

snap.forEach(function (child) {

var b = child.val();

b.id = child.key;

branches.push(b);

});

showBranches(branches, false);

});

}



function showBranches(branches, dist) {

var list = document.getElementById('branchList');



if (branches.length === 0) {

list.innerHTML = '<div class="empty">No branches found. Add your first branch!</div>';

return;

}



var html = '<h2>' + (dist ? 'Nearest Branches' : 'All Branches') + '</h2>';



for (var i = 0; i < branches.length; i++) {

var b = branches[i];

html += '<div class="branch-card">';

html += '<div class="branch-header"><h3>📍 ' + b.name + '</h3></div>';

html += '<div class="branch-details">';

html += '<div class="detail"><span class="label">Address:</span><span class="value">' + b.address + '</span></div>';

html += '<div class="detail"><span class="label">Phone:</span><span class="value">' + (b.phone || 'N/A') + '</span></div>';

html += '<div class="detail"><span class="label">Coordinates:</span><span class="value">' + b.latitude.toFixed(4) + ', ' + b.longitude.toFixed(4) + '</span></div>';

if (dist) {

html += '<div class="detail"><span class="label">Distance:</span><span class="value distance-highlight">' + b.distance.toFixed(2) + ' km</span></div>';

}

html += '</div>';

html += '<div class="branch-actions">';

html += '<button onclick="openMaps(' + b.latitude + ', ' + b.longitude + ')" class="btn btn-small btn-primary">Open in Maps</button>';

html += '<button onclick="removeBranch(\'' + b.id + '\')" class="btn btn-small btn-danger">Delete</button>';

html += '</div>';

html += '</div>';

}



list.innerHTML = html;

}



function addBranchScreen() {

var html = '<div class="screen">';

html += '<div class="header">';

html += '<button onclick="branchScreen()" class="btn btn-small">← Back</button>';

html += '<h1>Add New Branch</h1>';

html += '</div>';



html += '<div class="card">';

html += '<input type="text" id="branchName" placeholder="Branch Name" class="input" />';

html += '<input type="text" id="branchAddress" placeholder="Address" class="input" />';

html += '<input type="tel" id="branchPhone" placeholder="Phone Number" class="input" />';

html += '<label class="label">Location:</label>';

html += '<button onclick="useMyLocation()" class="btn btn-secondary btn-full">📍 Use Current Location</button>';

html += '<div class="location-inputs">';

html += '<input type="number" id="branchLat" placeholder="Latitude" class="input" step="any" />';

html += '<input type="number" id="branchLon" placeholder="Longitude" class="input" step="any" />';

html += '</div>';

html += '<div id="branchLocationStatus" class="status-message"></div>';

html += '<button onclick="saveBranch()" class="btn btn-primary btn-full">Add Branch</button>';

html += '</div></div>';

document.getElementById('app').innerHTML = html;

}